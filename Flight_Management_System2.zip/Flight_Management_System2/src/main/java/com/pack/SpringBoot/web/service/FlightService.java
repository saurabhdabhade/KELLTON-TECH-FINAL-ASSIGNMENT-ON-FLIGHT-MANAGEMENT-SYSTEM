package com.pack.SpringBoot.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.SpringBoot.web.data.model.Flights;
import com.pack.SpringBoot.web.data.model.Passengers;
import com.pack.SpringBoot.web.repository.FlightsRepository;

@Service
public class FlightService {

	@Autowired
	FlightsRepository flightsRepository;

	public List<Flights> findAllFlights() {
		List<com.pack.SpringBoot.web.data.model.Flights> flightsList = flightsRepository.findAll();
		return flightsList;
	}

	public Flights addFlightsDetails(Flights flights) {

		return flightsRepository.save(flights);
	}

	public Flights findDetailsByFlight_code(int id) {
		Optional<Flights> flightOpt = flightsRepository.findById(id);
		if (flightOpt.isPresent()) {
			Flights flight = flightOpt.get();
			return flight;
		} else {
			return null;
		}
	}

	public Flights updateFlightsDetails(int id, com.pack.SpringBoot.web.api.model.Flights flightsDetails) {
		Optional<Flights> flightOpt = flightsRepository.findById(id);
		if (flightOpt.isPresent()) {
			Flights flight = flightOpt.get();
			flight.setDestination(flightsDetails.getDestination());
			flight.setNoOfSeats(flightsDetails.getNoOfSeats());
			flight.setSources(flightsDetails.getSources());
			flight.setTakeOfDate(flightsDetails.getTakeOfDate());

			flight.setTicketId(flightsDetails.getTicketId());
			com.pack.SpringBoot.web.data.model.Flights updatedFlights = flightsRepository.save(flight);
			return updatedFlights;
		} else {
			return null;
		}

	}

	public void removeFlightsDetails(int id) {
		Optional<Flights> flightOpt = flightsRepository.findById(id);
		if (flightOpt.isPresent()) {
			Flights flight = flightOpt.get();
			flightsRepository.delete(flight);
		}
	}
}
