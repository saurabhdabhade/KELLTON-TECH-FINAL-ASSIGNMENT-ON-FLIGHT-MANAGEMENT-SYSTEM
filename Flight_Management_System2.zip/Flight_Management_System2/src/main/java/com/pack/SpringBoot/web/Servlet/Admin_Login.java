package com.pack.SpringBoot.web.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;

@WebServlet("/adminLogin")
public class Admin_Login extends HttpServlet{
	@RequestMapping("/adminLogin")
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
			String email=req.getParameter("username");
			String password=req.getParameter("password");
			
			HttpSession session=req.getSession();
			if("admin@flight.com".equals(email) && "admin".equals(password))
			{
				session.setAttribute("adminObj", new Object());
				resp.sendRedirect("admin/index.jsp");
			}
			else 
			{
				session.setAttribute("errorMsg", "invalid email or password");
				resp.sendRedirect("Admin_Login.jsp");
			}
		}
}
