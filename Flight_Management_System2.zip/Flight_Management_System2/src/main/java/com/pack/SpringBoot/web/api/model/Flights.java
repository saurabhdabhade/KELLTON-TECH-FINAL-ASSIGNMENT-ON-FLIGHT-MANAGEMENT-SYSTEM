package com.pack.SpringBoot.web.api.model;

import java.util.Date;

public class Flights {
	

	private int noOfSeats;

	private Date takeOfDate;

	private String sources;
	private String destination;
	private int ticketId;
	private int id;

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public Date getTakeOfDate() {
		return takeOfDate;
	}

	public void setTakeOfDate(Date takeOfDate) {
		this.takeOfDate = takeOfDate;
	}

	public String getSources() {
		return sources;
	}

	public void setSources(String sources) {
		this.sources = sources;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Flights [noOfSeats=" + noOfSeats + ", takeOfDate=" + takeOfDate + ", sources=" + sources
				+ ", destination=" + destination + ", ticketId=" + ticketId + ", id=" + id + "]";
	}

	
	
	

}
