package com.pack.SpringBoot.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.SpringBoot.web.data.model.CancellationTickets;
import com.pack.SpringBoot.web.repository.CancellationRepository;

@Service
public class CancellationTicketService {

	@Autowired
	CancellationRepository cancellationRepository;

	public List<CancellationTickets> findAllCancellationTickets() {
		List<com.pack.SpringBoot.web.data.model.CancellationTickets> cancellationTicketsList = cancellationRepository
				.findAll();
		return cancellationTicketsList;
	}

	public CancellationTickets addCancellationTicketsDetails(CancellationTickets cancellationTickets) {

		return cancellationRepository.save(cancellationTickets);
	}

	public CancellationTickets findDetailsByCancellation_Id(int cancellationId) {
		return cancellationRepository.findBycancellationId(cancellationId);
	}

	public CancellationTickets updateCancellationTickets(int cancellation_Id,
			com.pack.SpringBoot.web.api.model.CancellationTickets cancellationDetails) {
		com.pack.SpringBoot.web.data.model.CancellationTickets cancellationTickets = cancellationRepository
				.findBycancellationId(cancellation_Id);

		cancellationTickets.setAmount(cancellationDetails.getAmount());
		cancellationTickets.setCancellationDate(cancellationDetails.getCancellationDate());
		cancellationTickets.setFlightCode(cancellationDetails.getFlightCode());
		cancellationTickets.setGender(cancellationDetails.getGender());
		cancellationDetails.setPassportNumber(cancellationDetails.getPassportNumber());
		cancellationDetails.setPhone(cancellationDetails.getPhone());
		cancellationTickets.setTicketId(cancellationDetails.getTicketId());
		com.pack.SpringBoot.web.data.model.CancellationTickets updatedCancellationTickets = cancellationRepository
				.save(cancellationTickets);
		return updatedCancellationTickets;
	}

	public void removeCancellationTicketsDetails(int cancellation_Id) {
		com.pack.SpringBoot.web.data.model.CancellationTickets cancellationTickets = cancellationRepository
				.findBycancellationId(cancellation_Id);

		cancellationRepository.delete(cancellationTickets);

	}

}
