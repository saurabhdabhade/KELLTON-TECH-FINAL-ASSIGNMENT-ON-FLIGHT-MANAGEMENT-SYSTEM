package com.pack.SpringBoot.web.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.SpringBoot.web.data.model.Passengers;
import com.pack.SpringBoot.web.repository.PassengersRepository;

@Service
public class PassengerService {

	@Autowired
	PassengersRepository passengersRepository;

	public List<com.pack.SpringBoot.web.data.model.Passengers> findAllPassengers() {
		List<com.pack.SpringBoot.web.data.model.Passengers> passengersList = passengersRepository.findAll();
		return passengersList;

	}

	public Passengers addPassengerDetails(Passengers passenger) {

		return passengersRepository.save(passenger);
	}

	public Passengers findDetailsByPassengerId(int id) {
		Optional<Passengers> passengerOpt = passengersRepository.findById(id);
		if (passengerOpt.isPresent()) {
			Passengers passenger = passengerOpt.get();
			return passenger;
		} else {
			return null;
		}
	}

	public com.pack.SpringBoot.web.data.model.Passengers updatePassengersDetails(int id,
			com.pack.SpringBoot.web.api.model.Passengers passengerDetails) {
		Optional<Passengers> passengerOpt = passengersRepository.findById(id);
		if (passengerOpt.isPresent()) {
			Passengers passenger = passengerOpt.get();
			passenger.setAddress(passengerDetails.getAddress());
			passenger.setGender(passengerDetails.getGender());
			passenger.setNationality(passengerDetails.getNationality());
			passenger.setPassenger_name(passengerDetails.getPassenger_name());

			passenger.setPassportNumber(passengerDetails.getPassportNumber());
			passenger.setPhone(passengerDetails.getPhone());
			passenger.setTicketId(passengerDetails.getTicketId());
			com.pack.SpringBoot.web.data.model.Passengers updatedPassenger = passengersRepository.save(passenger);
			return updatedPassenger;
		} else {
			return null;
		}
	}

	public void removePassengerDetails(int id) {
		Optional<Passengers> passengerOpt = passengersRepository.findById(id);
		if (passengerOpt.isPresent()) {
			Passengers passenger = passengerOpt.get();

			passengersRepository.delete(passenger);
		}
	}

}
