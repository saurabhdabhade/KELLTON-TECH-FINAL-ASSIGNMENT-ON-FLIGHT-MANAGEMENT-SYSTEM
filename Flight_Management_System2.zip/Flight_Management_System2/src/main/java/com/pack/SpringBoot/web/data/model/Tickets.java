package com.pack.SpringBoot.web.data.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "tickets")
@EntityListeners(AuditingEntityListener.class)
public class Tickets {
	private String passenger_name;
	private String nationality;
	private int amount;
	private Long phone;
	private String gender;
	private int flightCode;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int passportNumber;
	
	public String getPassenger_name() {
		return passenger_name;
	}
	public void setPassenger_name(String passenger_name) {
		this.passenger_name = passenger_name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(int flightCode) {
		this.flightCode = flightCode;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}
	@Override
	public String toString() {
		return "Tickets [passenger_name=" + passenger_name + ", nationality=" + nationality + ", amount=" + amount
				+ ", phone=" + phone + ", gender=" + gender + ", flightCode=" + flightCode + ", id=" + id
				+ ", passportNumber=" + passportNumber + "]";
	}
}
