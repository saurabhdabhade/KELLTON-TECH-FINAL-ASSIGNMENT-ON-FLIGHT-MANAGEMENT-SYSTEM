package com.pack.SpringBoot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.pack.SpringBoot.web.api.model.AdminLogin;
import com.pack.SpringBoot.web.api.model.Flights;
import com.pack.SpringBoot.web.service.AdminService;

public class AdminController {
	@Autowired
	AdminService adminService;

	@GetMapping("/admin")
	public List<com.pack.SpringBoot.web.data.model.AdminLogin> getAllAdminLogin() {

		return adminService.findAllAdminLogin();
	}

	@PostMapping("/admin")
	public com.pack.SpringBoot.web.data.model.AdminLogin addAdminLogin(
			@RequestBody com.pack.SpringBoot.web.data.model.AdminLogin adminLogin) {

		return adminService.addAdminLoginDetails(adminLogin);
	}

	@GetMapping("/admin/{id}")
	public com.pack.SpringBoot.web.data.model.AdminLogin getAdminLoginById(
			@PathVariable(value = "id") int id) {

		return adminService.findDetailsByAdminLogin(id);

	}

	@PutMapping("/admin/{id}")
	public com.pack.SpringBoot.web.data.model.AdminLogin updateAdminLogin(
			@PathVariable(value = "id") int id, @RequestBody AdminLogin adminLoginDetails) {
		return adminService.updateAdminLoginDetails(id, adminLoginDetails);

	}

	@DeleteMapping("/admin/{id}")
	public ResponseEntity<?> deleteAdminLogin(@PathVariable(value = "id") int id) {

		adminService.removeAdminLoginDetails(id);
		return ResponseEntity.ok().build();
	}
}
