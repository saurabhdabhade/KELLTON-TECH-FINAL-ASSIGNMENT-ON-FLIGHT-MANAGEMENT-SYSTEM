package com.pack.SpringBoot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.SpringBoot.web.api.model.Flights;
import com.pack.SpringBoot.web.repository.FlightsRepository;
import com.pack.SpringBoot.web.service.FlightService;

@RestController
public class FlightController {

	@Autowired
	FlightService flightService;

	@GetMapping("/flights")
	public List<com.pack.SpringBoot.web.data.model.Flights> getAllFlights() 
	{
		return flightService.findAllFlights();
	}

	
	  @PostMapping("/flights")
	  public com.pack.SpringBoot.web.data.model.Flights addFlights(
	  @RequestBody com.pack.SpringBoot.web.data.model.Flights flights) 
	  {
	  return flightService.addFlightsDetails(flights); 
	  }
	
	/*
	 * @PostMapping("/flights") public String registerPassenger(@ModelAttribute
	 * Flights flights) { flightService.addFlightsDetails(flights);
	 * System.out.println(flights); return "redirect:/"; }
	 */

	@GetMapping("/flights/{id}")
	public com.pack.SpringBoot.web.data.model.Flights getFlightsById(@PathVariable(value = "id") int id) {

		return flightService.findDetailsByFlight_code(id);

	}

	@PutMapping("/flights/{id}")
	public com.pack.SpringBoot.web.data.model.Flights updateFlights(@PathVariable(value = "id") int id,
			@RequestBody Flights flightsDetails) {
		return flightService.updateFlightsDetails(id, flightsDetails);

	}

	@DeleteMapping("/flights/{id}")
	public ResponseEntity<?> deleteFlights(@PathVariable(value = "id") int id) {

		flightService.removeFlightsDetails(id);
		return ResponseEntity.ok().build();
	}
}
