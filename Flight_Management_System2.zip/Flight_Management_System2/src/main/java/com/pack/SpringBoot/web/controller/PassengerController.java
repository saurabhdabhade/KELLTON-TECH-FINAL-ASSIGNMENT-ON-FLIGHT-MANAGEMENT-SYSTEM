package com.pack.SpringBoot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.SpringBoot.web.api.model.Passengers;
import com.pack.SpringBoot.web.repository.PassengersRepository;
import com.pack.SpringBoot.web.service.PassengerService;

@RestController
public class PassengerController {
	@Autowired
	PassengersRepository passengersRepository;

	@Autowired
	PassengerService passengerService;

	@GetMapping("/passengers")
	public List<com.pack.SpringBoot.web.data.model.Passengers> getAllPassengers() {

		return passengerService.findAllPassengers();
	}

	@PostMapping("/passengers")
	public com.pack.SpringBoot.web.data.model.Passengers createPassengers(
			@RequestBody com.pack.SpringBoot.web.data.model.Passengers passenger) {

		return passengerService.addPassengerDetails(passenger);
	}

	@GetMapping("/passengers/{id}")
	public com.pack.SpringBoot.web.data.model.Passengers getByPassengersId(
			@PathVariable(value = "id") int id) {

		return passengerService.findDetailsByPassengerId(id);

	}

	@PutMapping("/passengers/{id}")
	public com.pack.SpringBoot.web.data.model.Passengers updatePassengers(
			@PathVariable(value = "id") int id, @RequestBody Passengers passengerDetails) {
		return passengerService.updatePassengersDetails(id, passengerDetails);
		
	}

	@DeleteMapping("/passengers/{id}")
	public ResponseEntity<?> deletePassengers(@PathVariable(value = "passenger_Id") int id) {
		
		passengerService.removePassengerDetails(id);
		return ResponseEntity.ok().build();
	}
}
