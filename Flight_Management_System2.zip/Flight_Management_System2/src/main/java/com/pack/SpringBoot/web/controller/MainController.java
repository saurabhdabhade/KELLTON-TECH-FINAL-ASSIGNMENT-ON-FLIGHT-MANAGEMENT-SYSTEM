package com.pack.SpringBoot.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.SpringBoot.web.api.model.Flights;

@Controller
public class MainController {

	@RequestMapping("/")
	public String welcome()
	{
		//System.out.println("This Is Welcome Page");
		return "welcome";
	}
	
	@RequestMapping("/Admin_Login")
	public String admin_Login()
	{
		//System.out.println("This Is Contact Page");
		return "Admin_Login";
	}
	
	@RequestMapping("/Welcome_To_AirLines")
	public String Welcome_To_AirLines()
	{
		//System.out.println("This Is Contact Page");
		return "Welcome_To_AirLines";
	}
	
	@RequestMapping("/flights")
	public String flights()
	{
		//System.out.println("This Is Contact Page");
		return "Flights";
	}
	
	@RequestMapping("/passengers")
	public String passengers()
	{
		//System.out.println("This Is Contact Page");
		return "Passengers";
	}
	
	@RequestMapping("/tickets")
	public String tickets()
	{
		//System.out.println("This Is Contact Page");
		return "Tickets";
	}
	
	@RequestMapping("/cancellation_of_ticket")
	public String Cancellation_Of_Ticket()
	{
		//System.out.println("This Is Contact Page");
		return "Cancellation_Of_Ticket";
	}
	
	/*
	 * @RequestMapping("/fligts",method =RequestMethod.GET) public String
	 * getpage(Model model) { Flights flights = new Flights();
	 * model.addAttribute("flights", flights);
	 * //System.out.println("This Is Contact Page"); return "welcome"; }
	 */
}
