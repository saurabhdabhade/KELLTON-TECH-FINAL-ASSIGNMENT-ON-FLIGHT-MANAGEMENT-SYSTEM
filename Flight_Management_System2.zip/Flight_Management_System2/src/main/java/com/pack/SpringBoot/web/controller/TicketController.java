package com.pack.SpringBoot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.SpringBoot.web.api.model.Tickets;
import com.pack.SpringBoot.web.repository.TicketsRepository;
import com.pack.SpringBoot.web.service.TicketService;

@RestController
public class TicketController {
	@Autowired
	TicketsRepository ticketsRepository;

	@Autowired
	TicketService ticketService;
	
	@GetMapping("/tickets")
	public List<com.pack.SpringBoot.web.data.model.Tickets> getAllTickets() {

		return ticketService.findAllTickets();
	}

	@PostMapping("/tickets")
	public com.pack.SpringBoot.web.data.model.Tickets addTickets(
			@RequestBody com.pack.SpringBoot.web.data.model.Tickets tickets) {

		return ticketService.addTicketsDetails(tickets);
	}

	@GetMapping("/tickets/{id}")
	public com.pack.SpringBoot.web.data.model.Tickets getTicketsById(
			@PathVariable(value = "id") int id) {

		return ticketService.findDetailsByTicketsId(id);

	}

	@PutMapping("/tickets/{id}")
	public com.pack.SpringBoot.web.data.model.Tickets updateTickets(
			@PathVariable(value = "id") int id, @RequestBody Tickets ticketDetails) {
		return ticketService.updateTicketsDetails(id, ticketDetails);
		
	}

	@DeleteMapping("/tickets/{ticketId}")
	public ResponseEntity<?> deletePassengers(@PathVariable(value = "id") int id) {
		
		ticketService.removeTicketsDetails(id);
		return ResponseEntity.ok().build();
	}
}
