package com.pack.SpringBoot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.SpringBoot.web.api.model.CancellationTickets;
import com.pack.SpringBoot.web.service.CancellationTicketService;

@RestController
public class CancellationTicketController {

	@Autowired
	CancellationTicketService cancellationTicketService;

	@GetMapping("/cancellation_of_ticket")
	public List<com.pack.SpringBoot.web.data.model.CancellationTickets> getAllFlights() {

		return cancellationTicketService.findAllCancellationTickets();
	}

	@PostMapping("/cancellation_of_ticket")
	public com.pack.SpringBoot.web.data.model.CancellationTickets addCancellationTickets(
			@RequestBody com.pack.SpringBoot.web.data.model.CancellationTickets cancellationTickets) {

		return cancellationTicketService.addCancellationTicketsDetails(cancellationTickets);
	}

	@GetMapping("/cancellation_of_ticket/{cancellationId}")
	public com.pack.SpringBoot.web.data.model.CancellationTickets getCancellationTicketsById(
			@PathVariable(value = "cancellation_Id") int cancellationId) {

		return cancellationTicketService.findDetailsByCancellation_Id(cancellationId);

	}

	@PutMapping("/cancellation_of_ticket/{cancellationId}")
	public com.pack.SpringBoot.web.data.model.CancellationTickets updateCancellationTickets(
			@PathVariable(value = "cancellation_Id") int cancellationId,
			@RequestBody CancellationTickets cancellationDetails) {
		return cancellationTicketService.updateCancellationTickets(cancellationId, cancellationDetails);

	}

	@DeleteMapping("/cancellation_of_ticket/{cancellationId}")
	public ResponseEntity<?> deleteCancellationTickets(@PathVariable(value = "cancellationId") int cancellationId) {

		cancellationTicketService.removeCancellationTicketsDetails(cancellationId);
		return ResponseEntity.ok().build();
	}

}
