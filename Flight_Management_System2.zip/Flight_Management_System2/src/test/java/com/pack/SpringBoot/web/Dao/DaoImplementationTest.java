package com.pack.SpringBoot.web.Dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DaoImplementationTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
